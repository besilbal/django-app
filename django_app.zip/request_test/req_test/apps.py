from django.apps import AppConfig


class ReqTestConfig(AppConfig):
    name = 'req_test'
